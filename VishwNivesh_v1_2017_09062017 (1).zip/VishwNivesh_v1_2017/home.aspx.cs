﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            f_GetStrategyList();
            // StrategyList.Controls.Add(new Literal { Text = f_GetplacholderStrategy("ATPB00001").ToString() });
        }
        string constr = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT ScriptName, BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (StrategyId = 'ATPB00001') ORDER BY OrderDate DESC"))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        gvDefaultstock.DataSource = dt;
                        gvDefaultstock.DataBind();
                    }
                }
            }
        }

        if (Session["UserName"] != null)
        {
            btnSubscribPay.Visible = false;
            string constrr = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constrr))
            {
                //if user is login then it come default.
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT ScriptName, BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (StrategyId = 'ATPB00001') ORDER BY OrderDate DESC"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            gvAllStocks.DataSource = dt;
                            gvAllStocks.DataBind();
                        }
                    }
                }
            }
        }
        else
        {
            // Response.Redirect("#");
            //  ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
        }

        //   PlaceStockData.Controls.Add(new Literal { Text = f_GetplacholderStock("ATPB00001").ToString() });

        //PlaceStockData.Controls.Add(new Literal { Text = f_GetplacholderStock().ToString() });

        //  PlaceBuyOrders.Controls.Add(new Literal { Text = f_GetplacholderBuyOrders("22").ToString() });
        //  PlaceSellOrder.Controls.Add(new Literal { Text = f_GetplacholderSellOrders("22").ToString() });

        f_TradeHistory("22");
      // PlaceTradeHistory.Controls.Add(new Literal { Text = f_GetplacholderTradeHistory("22").ToString() });
        f_GetOHLC("NC22");

    }

    StringBuilder f_GetplacholderStrategy(string strStrategyid)
    {
        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT DISTINCT ScriptName, BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (StrategyId = '" + strStrategyid + "') ORDER BY OrderDate DESC";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            int i = 1;
            //decimal profit = 0;
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    table.Append("<tr href='" + rd[0].ToString() + "'><td width='40%'>" + rd[0].ToString().Split(' ')[0] + "</td><td width='60%' id='balance_" + i + "'>" +
                        rd[1].ToString() + "</td> </tr>");
                    //profit = decimal.Parse(rd[1].ToString()) + profit;
                    if (rd[1].ToString() == "LONGENTRY")
                    {
                        BuyStockPrice.Text = rd[2].ToString();
                        BuyStockQty.Text = "1";
                        BuyStockTotal.Text = decimal.Parse(rd[2].ToString()) * int.Parse(BuyStockQty.Text) + "";
                    }
                    else
                    {
                        txtSellPrice.Text = rd[2].ToString();
                        txtSellQty.Text = "1";
                        txtSellTotal.Text = decimal.Parse(rd[2].ToString()) * int.Parse(txtSellQty.Text) + "";
                    }
                }
            }
            rd.Close();
            con.Close();
            i++;
            //profit = profit / i;
            //lblestProfit.Text = profit + "";
        }
        catch
        {
        }
        return table;
    }

    StringBuilder f_GetplacholderStock(string strStrategyid)
    {



        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT DISTINCT ScriptName, BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (StrategyId = '" + strStrategyid + "') ORDER BY OrderDate DESC";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    table.Append("<tr class='rom odd' role='row'><td width='25%' class='first'>" + rd[0].ToString() +
                        "<div class='rom'></div></td><td width='33%'>" + rd[2].ToString() + "</td><td width='16%'>" + rd[1].ToString() + "</td></tr>");
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
        return table;
    }

    StringBuilder f_GetplacholderBuyOrders(string strScriptCode)
    {
        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (ScriptCode = '" + strScriptCode + "' and BuySell='LONGENTRY' OR BuySell='SHORTEXIT')";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    table.Append("<tr class='clRow ' title='Total DASH: 0.57266904, Total BTC: 0.02912204'><td width='35%' class='first'>" + rd[1].ToString() + "</td><td width='38%'>" + rd[0].ToString() + "</td><td width='27%'>" + rd[2].ToString() + "</td></tr>");
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
        return table;
    }
    StringBuilder f_GetplacholderSellOrders(string strScriptCode)
    {
        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT BuySell, ORDERPRICE, OrderDate FROM tblOrdersWeb WHERE (ScriptCode = '" + strScriptCode + "' and (BuySell='LONGEXIT' OR BuySell='SHORTENTY'))";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    table.Append("<tr class='clRow ' title='Total DASH: 0.57266904, Total BTC: 0.02912204'><td width='35%' class='first'>" + rd[1].ToString() + "</td><td width='38%'>" + rd[0].ToString() + "</td><td width='27%'>" + rd[2].ToString() + "</td></tr>");
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
        return table;
    }

    StringBuilder f_GetplacholderTradeHistory(string strScriptCode)
    {
        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT  OrderDate,BuySell, ORDERPRICE FROM tblOrdersWeb WHERE (ScriptCode = '" + strScriptCode + "')";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    if (rd[1].ToString() == "LONGEXIT" || rd[1].ToString() == "SHORTENTRY")
                        table.Append("<tr class='red'><td width='40%' class='first' title='" + DateTime.Parse(rd[0].ToString()).ToString("hh:mm:ss") + "'>" + rd[0].ToString() + "</td><td width='30%'>" + rd[1].ToString() + "</td><td width='30%'>" + rd[2].ToString() + "</td></tr>");
                    else
                        table.Append("<tr class='green'><td width='40%' class='first' title='" + rd[0].ToString() + "'>" + rd[0].ToString() + "</td><td width='30%'>" + rd[1].ToString() + "</td><td width='30%'>" + rd[2].ToString() + "</td></tr>");
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
        return table;
    }
    void f_TradeHistory(string strScriptCode)
    {
        string constrr = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constrr))
        {
            //if user is login then it come default.
            using (SqlCommand cmd = new SqlCommand("SELECT  OrderDate,BuySell, ORDERPRICE FROM tblOrdersWeb WHERE (ScriptCode = '" + strScriptCode + "')"))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        gvOrderHistory.DataSource = dt;
                        gvOrderHistory.DataBind();
                    }
                }
            }
        }
    }

    StringBuilder f_GetOHLC(string strScriptCode)
    {
        StringBuilder table = new StringBuilder();
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT top(1) OpenPrice, HighPrice,LowPrice,ClosePrice FROM tblYahooData WHERE (ScripCode = '" + strScriptCode + "') order By times desc";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    lblOpen.Text = rd[0].ToString();
                    lblHigh.Text = rd[1].ToString();
                    lblLow.Text = rd[2].ToString();
                    lblClose.Text = rd[3].ToString();
                    lblBuyprice.Text = rd[3].ToString();
                    lblBuyScript.Text = strScriptCode;
                    lblSellPrice.Text = rd[3].ToString();
                    lblSellScript.Text = strScriptCode;
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
        return table;
    }

    void f_GetStrategyList()
    {
        try
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT [StatID], [StrategyInfo] FROM [tblStrategies]";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    ListItem item = new ListItem();
                    item.Text = rd[1].ToString().Split(' ')[0];
                    item.Value = rd[0].ToString();
                    ddlStrategyList.Items.Add(item);
                }
            }
            rd.Close();
            con.Close();
        }
        catch
        {
        }
    }
    protected void ddlStrategyList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (false)
        {
            //Show result of all strategies
            // StrategyList.Controls.Add(new Literal { Text = f_GetplacholderStrategy("ATPB00001").ToString() });
            PlaceStockData.Controls.Add(new Literal { Text = f_GetplacholderStock("ATPB00001").ToString() });
        }
        else
        {

        }
    }
    protected void btnBuy_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Kindly Do Registration for order Execution')</script>");
        }
        else
        {
            //Send order for manual Execution 
            // BuyStockPrice.Text,BuyStockQty.Text, lblBuyScript.Text;
        }
    }
    protected void btnSell_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Kindly Do Registration for order Execution')</script>");
        }
        else
        {
            //Send order for Manual Execution
            //txtSellPrice.Text,txtSellQty.Text,lblSellScript.Text;
        }
    }
    protected void btnSubscribPay_Click(object sender, EventArgs e)
    {
        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Go to Payment gateway')</script>");
    }
}