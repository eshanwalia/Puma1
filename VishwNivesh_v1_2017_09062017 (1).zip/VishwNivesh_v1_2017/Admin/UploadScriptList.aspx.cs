﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Data;
using System.IO;
using System.Xml;
using System.Net;

public partial class Admin_UploadScriptList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Upload(object sender, EventArgs e)
    {
        //Upload and save the file
        string excelPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.SaveAs(excelPath);

        string conString = string.Empty;
        string extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
        switch (extension)
        {
            case ".xls": //Excel 97-03
                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                break;
            case ".xlsx": //Excel 07 or higher
                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
                break;

        }
        conString = string.Format(conString, excelPath);
        using (OleDbConnection excel_con = new OleDbConnection(conString))
        {
            excel_con.Open();
            string sheet1 = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
            DataTable dtExcelData = new DataTable();

            ////[OPTIONAL]: It is recommended as otherwise the data will be considered as String by default.
            //dtExcelData.Columns.AddRange(new DataColumn[3] { new DataColumn("Id", typeof(int)),
            //    new DataColumn("Name", typeof(string)),
            //    new DataColumn("Salary",typeof(decimal)) });

            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excel_con))
            {
                oda.Fill(dtExcelData);
            }
            excel_con.Close();

            string consString = "Data Source=208.91.198.196;Initial Catalog=puma_raptor;Persist Security Info=True;User ID=puma;Password=Nivesh@2010";// ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(consString))
            {
                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(conn))
                {
                    //Set the database table name
                    sqlBulkCopy.DestinationTableName = "tblNiftyScripts";

                    //[OPTIONAL]: Map the Excel columns with that of the database table
                    sqlBulkCopy.ColumnMappings.Add("CompanyName", "CompanyName");
                    sqlBulkCopy.ColumnMappings.Add("Industry", "Industry");
                    sqlBulkCopy.ColumnMappings.Add("Symbol", "Symbol");
                    sqlBulkCopy.ColumnMappings.Add("Series", "Series");
                    sqlBulkCopy.ColumnMappings.Add("ISINCode", "ISINCode");
                    sqlBulkCopy.ColumnMappings.Add("scripcode", "scripcode");
                    sqlBulkCopy.ColumnMappings.Add("ScripName", "ScripName");
                    conn.Open();
                    sqlBulkCopy.WriteToServer(dtExcelData);
                    conn.Close();
                }
            }
        }

        //SqlConnection con = new SqlConnection();
        //con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB"].ConnectionString;
        //con.Open();
        //SqlCommand cmd = new SqlCommand();
        //cmd.CommandText = "select Symbol from tblNiftyScripts where activestate is null";
        //cmd.Connection = con;
        //SqlDataReader rd = cmd.ExecuteReader();

        //if (rd.HasRows)
        //{
        //    while (rd.Read())
        //    {
        //        //DateTime dtReleasDate = DateTime.Parse(rd[2].ToString());
        //        //table.Append("<li><a href='" + rd[1] + "' target='_blank' data-toggle='tooltip' title=" + rd[0] + ">" + rd[0].ToString().Replace('_', ' ') + "</a></li>");

        //        ////Update yahoo code and insert into table
        //        //string searchPattern = "*" + rowID.ToString() + "*"; // adapt as required
        //        //string[] files = Directory.GetFiles("YourDirectory", searchPattern);
        //        YAPIHelper obj = new YAPIHelper();
        //        if (YAPIHelper.getQuotesXML(rd[2].ToString() + ".NC").Quotes.Count > 0)
        //        {
        //            using (var connection = new SqlConnection(con.ConnectionString))
        //            using (var command = new SqlCommand("UPDATE tblNiftyScripts SET YahooSymbol = @yahooSymbol, ActiveSate=1 WHERE Symbol = @Symbol", connection))
        //            {
        //                command.Parameters.AddWithValue("@yahooSymbol", rd[0].ToString() + ".NC");
        //                command.Parameters.AddWithValue("@Symbol", rd[0].ToString());
        //                command.ExecuteNonQuery();
        //            }
        //        }
        //    }
        //}

        //rd.Close();
        //con.Close();
    }

    void f_upldateyahoo()
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select Symbol from tblNiftyScripts where activestate is null";
        cmd.Connection = con;
        SqlDataReader rd = cmd.ExecuteReader();
        //Create a new DataTable.
        DataTable dtNifty100 = new DataTable("Nifty100");

        //Load DataReader into the DataTable.
        dtNifty100.Load(rd);
        rd.Close();
        con.Close();

        //if (rd.HasRows)
        //{
        //    while (rd.Read())
        //    {
        //DateTime dtReleasDate = DateTime.Parse(rd[2].ToString());
        //table.Append("<li><a href='" + rd[1] + "' target='_blank' data-toggle='tooltip' title=" + rd[0] + ">" + rd[0].ToString().Replace('_', ' ') + "</a></li>");

        ////Update yahoo code and insert into table
        //string searchPattern = "*" + rowID.ToString() + "*"; // adapt as required
        //string[] files = Directory.GetFiles("YourDirectory", searchPattern);

        for (int i = 0; i < dtNifty100.Rows.Count; i++)
        {
            YAPIHelper obj = new YAPIHelper();
            if (YAPIHelper.getQuotesXML(dtNifty100.Rows[i][0] + ".NS").Quotes.Count > 0)
            {
                using (var connection = new SqlConnection(con.ConnectionString))
                using (var command = new SqlCommand("UPDATE tblNiftyScripts SET YahooSymbol = @yahooSymbol, ActiveState=1 WHERE Symbol = @Symbol", connection))
                {
                    command.Parameters.AddWithValue("@yahooSymbol", dtNifty100.Rows[i][0] + ".NS");
                    command.Parameters.AddWithValue("@Symbol", dtNifty100.Rows[i][0]);
                    if (connection.State == ConnectionState.Closed)
                        connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        //    }
        //}


    }
    protected void btnUpdateAPI_Click(object sender, EventArgs e)
    {
        f_upldateyahoo();
    }
}
class YAPIHelper
{
    public static YahooQuoteResponse getQuotesXML(string scripCode)
    {
        YahooQuoteResponse yahooQuoteResponse = new YahooQuoteResponse();
        try
        {
            //string url = string.Format("http://chartapi.finance.yahoo.com/instrument/1.0/{0}/chartdata;type=quote;range=1d/xml/", scripCode);
            string url = string.Format("http://chartapi.finance.yahoo.com/instrument/1.0/{0}/chartdata;type=quote;range=1d/xml/", scripCode);
            WebRequest req = WebRequest.Create(url);
            WebResponse res = req.GetResponse();
            Stream stream = res.GetResponseStream();
            StreamReader reader = new StreamReader(stream);
            string strResponse = reader.ReadToEnd();
            XmlDocument doc = new XmlDocument();
            doc.Load(new StringReader(strResponse));
            XmlNodeList nodePList = doc.SelectNodes("data-series/series/p");

            yahooQuoteResponse.ScripCode = scripCode;
            foreach (XmlNode nodeP in nodePList)
            {
                XmlNodeList nodeValueList = nodeP.SelectNodes("v");
                Quote quote = new Quote();
                quote.Close = Convert.ToDecimal(nodeValueList[0].InnerText);
                quote.High = Convert.ToDecimal(nodeValueList[1].InnerText);
                quote.Low = Convert.ToDecimal(nodeValueList[2].InnerText);
                quote.Open = Convert.ToDecimal(nodeValueList[3].InnerText);
                quote.Volume = Convert.ToDecimal(nodeValueList[4].InnerText);
                quote.Time = new DateTime(1970, 1, 1).AddSeconds(Convert.ToInt64(nodeP.Attributes["ref"].Value)).ToLocalTime();
                yahooQuoteResponse.Quotes.Add(quote);
            }
            return yahooQuoteResponse;
        }
        catch (Exception ex)
        {
            //Classes.clsPath.f_WriteintoTextfile("error_logs", ex.Message + "|" + ex.Source + "|" + ex.TargetSite + "|" + ex.InnerException + "|" + ex.StackTrace + "|" + ex.HelpLink);
            //MessageBox.Show("Error: " + ex.Message);
        }
        return yahooQuoteResponse;
    }

    public class YahooQuoteResponse
    {

        public string ScripCode;

        public List<Quote> Quotes = new List<Quote>();
    }
    public class Quote
    {
        public DateTime Time;
        public Decimal Open;
        public Decimal High;
        public Decimal Close;
        public Decimal Low;
        public Decimal Volume;
    }
}