﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_AdminLogin : System.Web.UI.Page
{
    //clsAdminLogin_Logic objAmin = new clsAdminLogin_Logic();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //checkSqlInject objsqlInject = new checkSqlInject();
        //if (!objsqlInject.checkForSQLInjection(txtLoginId.Text.Trim()) & !objsqlInject.checkForSQLInjection(txtPassword.Text.Trim()))
        //{
        //    try
        //    {

        //        objAmin.AdminLoginId = clsAesCryp.Encrypt(txtLoginId.Text.Trim());
        //        objAmin.Password = clsAesCryp.Encrypt(txtPassword.Text.Trim());
        //        DataSet dsAdminLoginDetail = objAmin.GetAdminLoginDetails();
        //        DataRowCollection drc = dsAdminLoginDetail.Tables[0].Rows;
        //        if (drc.Count > 0)
        //        {
        //            lblError.Visible = false;
        //            DataRow dr = drc[0];
        //            Session["AdminId"] = clsAesCryp.Decrypt(dr["AdminLoginId"].ToString());
        //            Response.Redirect("frmAdminHome.aspx");
        //        }
        //        else
        //        {
        //            lblError.Visible = true;
        //            lblError.Text = "Invalid Login ID/Password";
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        lblError.Visible = true;
        //        lblError.Text = ex.Message.ToString();
        //    }
        //    Session["AdminId"] = "1";
        //    Response.Redirect("frmAdminHome.aspx");
        //}
        //else
        //{
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You have been attacked by SQL Injection')", true);
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Default.aspx");
    }
}