﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Data.SqlClient;

public partial class userRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegistration_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        try
        {
            //Code to register the user
            string strConnection = System.Configuration.ConfigurationManager.ConnectionStrings["VishwNivesh_DB"].ToString();
            con.ConnectionString = strConnection;
            //
            //Check is any field is empty
            //
            bool validate = false;
            if (txtFirstName.Text != "" && txtLastName.Text != "" && txtContactNo.Text != "" && txtUserName.Text != "" && txtPassword.Text != "")//&& txtPancarNo.Text != ""
                validate = true;
            if (strConnection != null && validate)
            {

                con.Open();
                string strQuery = null;
                strQuery = "select 1 from tbl_login where emailid='" + txtEmailId.Text.Trim() + "' and isDeleted <> 1";
                SqlCommand cmd = new SqlCommand(strQuery, con);
                string strresult = null;
                try
                {
                    strresult = cmd.ExecuteScalar().ToString();
                }
                catch (NullReferenceException ex)
                {
                    string str = ex.Message;
                }
                if (strresult != "1")
                {
                    SendMail(txtFirstName.Text.Trim(), txtUserName.Text.Trim(), txtPassword.Text.Trim());
                    SendMailforVarification(txtFirstName.Text.Trim(), txtLastName.Text.Trim(), txtContactNo.Text.Trim(), txtPancarNo.Text.Trim(), txtUserName.Text.Trim(), txtPassword.Text.Trim(), DateTime.Now.ToString("MM/dd/yyyy hh:mm"));

                    strQuery = "INSERT INTO tbl_login (firstname,lastname,contactno,emailid,pancardno,username,password,createdate,active,isadmin,isDeleted) values('" + txtFirstName.Text.Trim() + "','" + txtLastName.Text.Trim() + "','" + txtContactNo.Text.Trim() + "','" + txtEmailId.Text.Trim() + "','" + txtPancarNo.Text.Trim() + "','" + txtUserName.Text.Trim() + "','" + txtPassword.Text.Trim() + "','" + DateTime.Now.ToString("MM/dd/yyyy hh:mm") + "',0,0,0);";
                    cmd.CommandText = strQuery;
                    cmd.ExecuteNonQuery();

                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Check your email. Your account will be activated in four hours');  window.location.replace(\"index.aspx\");</script>");//www.vishwnivesh.com
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('User already exist. login with username and password')</script>");
                }
                cmd.Dispose();

            }
        }
        catch (Exception ex)
        {
            string str = ex.Message;
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Kindly fill the right details')</script>");
        }
        finally
        {
            con.Close();
        }
    }
    protected void SendMail(string strFirstName, string strUserName, string strPassword)
    {
        var fromAddress = "info@vishwnivesh.com";// Gmail Address from where you send the mail
        var toAddress = txtEmailId.Text.Trim().ToString();
        //  const string fromPassword = "nivesh1000";//Password of your gmail address
        string subject = "Your Login Created on VishwNivesh. Your account will be activated in four hours ";//YourSubject.Text.ToString();
        string body = "Hi " + strFirstName + ",\n\n";
        body += "\t Your Login is created with VishwNivesh with userid: " + strUserName + " \n with Password :" + strPassword + "\n";
        body += "Your account will be activated in four hours\n";
        body += "Thanks!!!\n\n Regards,\n";
        body += "VishwNivesh\n";

        SmtpClient objSmtpClient = new SmtpClient();
        objSmtpClient.EnableSsl = false;
        objSmtpClient.Send(fromAddress, toAddress, subject, body);
    }
    protected void SendMailforVarification(string strFirstName, string strLastname, string strContactNumber, string strPancardNumber, string strUserName, string strPassword, string strDateTime)
    {
        var fromAddress = "info@vishwnivesh.com";// Gmail Address from where you send the mail
        var toAddress = "vishwnivesh@gmail.com";
        //  const string fromPassword = "nivesh1000";//Password of your gmail address
        string subject = "New user has been created for VishwNivesh.com. On date of: " + strDateTime;//YourSubject.Text.ToString();
        string body = "Hi,\n\n";
        body += "First Name : \t " + strFirstName + "\n";
        body += "Last Name : \t " + strLastname + "\n";
        body += "Contact Number : \t " + strContactNumber + "\n";
        body += "PAN Card Number : \t " + strPancardNumber + "\n";
        body += "User Name : \t " + strUserName + "\n";
        body += "Password : \t " + strPassword + "\n\n";
        body += "This account has to be activated in next four hours on or Before :(" + DateTime.Parse(strDateTime).AddHours(4).ToString("MM/dd/yyyy hh:mm") + ")\n";
        body += "Login to: http://vishwnivesh.com/Login.aspx \n\n";
        body += "Thanks!!!\n\n Regards,\n";
        body += "VishwNivesh\n";
        SmtpClient objSmtpClient = new SmtpClient();
        objSmtpClient.EnableSsl = false;
        objSmtpClient.Send(fromAddress, toAddress, subject, body);
    }

}