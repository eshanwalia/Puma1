﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

public partial class strategy : System.Web.UI.Page
{
    StringBuilder table = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                //Set User name in Title of all pages
                // Page.Title = "Page Title";


                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB"].ConnectionString;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select StrategyName, StrategyURL, StInDate from tblStrategyList order by StrategyName";
                cmd.Connection = con;
                SqlDataReader rd = cmd.ExecuteReader();
                int index = 1;
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        DateTime dtReleasDate = DateTime.Parse(rd[2].ToString());
                        table.Append(" <tr><td>" + index + "</td><td><a href='" + rd[1] + "' target='_blank' data-toggle='tooltip' title=" + rd[0] + ">" + rd[0].ToString().Replace('_', ' ') + "</a></td> </tr>");
                        index++;
                    }
                }
                PlaceHolder1.Controls.Add(new Literal { Text = table.ToString() });
                rd.Close();
                con.Close();
            }
        }
        catch
        {
        }
    }
}