﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;

public partial class User_UserMasterPage : System.Web.UI.MasterPage
{
    StringBuilder table = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("UserLogin.aspx");
        }
        else
            try
            {
                if (!IsPostBack)
                {
                    //Set User name in Title of all pages
                    // Page.Title = "Page Title";


                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "SELECT custkey, StrategyInfo FROM dbo.tblStrategies WHERE (StatInfoUrl IS NOT NULL)";
                    //"select StrategyName, StrategyURL, StInDate from tblStrategyList order by StrategyName";
                    cmd.Connection = con;
                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.HasRows)
                    {
                        while (rd.Read())
                        {
                            table.Append("<li><a href='UserStrategySelection.aspx?StrategyID=" + rd[0].ToString() + "' data-toggle='tooltip' id=" + rd[0] +
                            " runat=server>" + rd[1].ToString().Replace('_', ' ') + "</a></li>");
                        }
                    }
                    PlaceHolder1.Controls.Add(new Literal { Text = table.ToString() });
                    rd.Close();
                    con.Close();
                }
            }
            catch
            {
            }
    }
}
