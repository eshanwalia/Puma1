﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_ExecuteOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Session["UserName"] == null) || (Session["UserName"].ToString() == ""))
        {
            Response.Redirect("Userlogin.aspx");
        }
        try
        {
            SqlCommand cmd1 = new SqlCommand("select clientid from tblRegClientSharekhan where userid=@userid");
            cmd1.Parameters.AddWithValue("@userid", Session["UserName"].ToString());
            //DataTable dt1 = GetData(cmd1);
            //lblClientID.Text = dt1.Rows[0][0].ToString();
            //lblUserID.Text = Session["UserName"].ToString().ToUpper();
            ////StrategyName
            //SqlCommand cmdstname = new SqlCommand("SELECT StrategyInfo FROM dbo.tblStrategies where custkey=@StrategyId");
            //cmdstname.Parameters.AddWithValue("@StrategyId", Request.QueryString["StrategyID"]);
            //DataTable dtcmdstname = GetData(cmdstname);
            //lblStrategyName.Text = dtcmdstname.Rows[0][0].ToString();


            //lblStrategyId.Text = Request.QueryString["StrategyID"];
            //lblScriptName.Text = Request.QueryString["ScripCode"];
            ////In below query have to update if we are spliting order send and send email subscription
            //string strQuery = "select 1 from tblSubcribLiveOrders where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
            //SqlCommand cmd = new SqlCommand(strQuery);
            //cmd.Parameters.AddWithValue("@Clinetid", lblClientID.Text.Trim());
            //cmd.Parameters.AddWithValue("@StrategyID", lblStrategyId.Text.Trim());
            //cmd.Parameters.AddWithValue("@ScripCode", lblScriptName.Text.Trim());
            //DataTable dt = GetData(cmd);
            //if (int.Parse(dt.Rows[0][0].ToString()) == 1)
            //{
            //    btnSubcribe.Text = "Unsubscribe";
            //    btnSubcribe.BackColor = System.Drawing.Color.Red;
            //}
            //else
            //{
            //    btnSubcribe.Text = "Subscribe";
            //    btnSubcribe.BackColor = System.Drawing.Color.Green;
            //}

            //FillTrainingsDetails();
        }
        catch
        {

        }
    }
}