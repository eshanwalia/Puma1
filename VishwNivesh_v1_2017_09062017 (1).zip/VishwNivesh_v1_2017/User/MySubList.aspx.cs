﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_MySubList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            datbind();
    }

    void datbind()
    {
        try
        {
            string strQuery = "SELECT DISTINCT ClientId,StrategyId,ScripCode from tblSubcribLiveOrders";
            SqlCommand cmd = new SqlCommand(strQuery);
            DataTable dt = clsSqldata.GetData(cmd);

            gvMaster.Visible = true;
            gvMaster.DataSource = dt;
            gvMaster.DataBind();

        }
        catch (Exception a)
        {
            // lblError.Text = (a.Message.ToString());
        }
    }
    protected void lnkUnsubscribe_Click(object sender, EventArgs e)
    {
        
    }
    protected void gvMaster_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //e.CommandArgument.ToString();

        //string strQuery;
        //SqlCommand cmd;
        ////update
        //strQuery = "update tblSubcribLiveOrders set SubscribActive=@SubscribActive where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
        //cmd = new SqlCommand(strQuery);
        //cmd.Parameters.AddWithValue("@SubscribActive", 0);
        //cmd.Parameters.AddWithValue("@Clinetid", gvMaster.SelectedRow.Cells[0].Text);
        //cmd.Parameters.AddWithValue("@StrategyID", gvMaster.SelectedRow.Cells[0].Text);
        //cmd.Parameters.AddWithValue("@ScripCode", gvMaster.SelectedRow.Cells[0].Text);
        //bool res =clsSqldata.InsertUpdateData(cmd);
    }
    protected void gvMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
     ////   TextBox1.Text = gvMaster.SelectedRow.Cells[0].Text;
     ////   int RowIndex = Convert.ToInt32(e.CommandArgument.ToString());
     //   string strQuery;
     //   SqlCommand cmd;
     //   //update
     //   strQuery = "update tblSubcribLiveOrders set SubscribActive=@SubscribActive where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
     //   cmd = new SqlCommand(strQuery);
     //   cmd.Parameters.AddWithValue("@SubscribActive", 0);
     //   cmd.Parameters.AddWithValue("@Clinetid", gvMaster.SelectedRow.Cells[0].Text);
     //   cmd.Parameters.AddWithValue("@StrategyID", gvMaster.SelectedRow.Cells[0].Text);
     //   cmd.Parameters.AddWithValue("@ScripCode", gvMaster.SelectedRow.Cells[0].Text);
     //   bool res = clsSqldata.InsertUpdateData(cmd);
    }
}