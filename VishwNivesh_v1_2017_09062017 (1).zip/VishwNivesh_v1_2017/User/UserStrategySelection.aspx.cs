﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class User_UserStrategySelection : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                lblStatID.Text = Request.QueryString["StrategyID"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "SELECT custkey, StrategyInfo, StatInfoUrl FROM dbo.tblStrategies WHERE (StatInfoUrl IS NOT NULL) and custkey='" + lblStatID.Text + "'";
                //"select StrategyName, StrategyURL, StInDate from tblStrategyList order by StrategyName";
                cmd.Connection = con;
                SqlDataReader rd = cmd.ExecuteReader();

                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        lblStrategyName.Text = rd[1].ToString();
                        ViewStrategy.HRef = rd[2].ToString();
                    }
                }
                rd.Close();
                con.Close();

                //View script list
                datbind();
            }
        }
        catch (Exception ex)
        {
        }
    }
    void datbind()
    {
        try
        {
            string strQuery = "SELECT TOP(SELECT COUNT(ScripName) AS Expr1 FROM dbo.ScriptListTable) " +
                "ScriptListTable_1.FullScripName, dbo.tblYahooData.ClosePrice, ScriptListTable_1.ScripName FROM dbo.ScriptListTable AS ScriptListTable_1 INNER JOIN " +
                "dbo.tblYahooData ON ScriptListTable_1.ScripName = dbo.tblYahooData.ScripCode ORDER BY dbo.tblYahooData.Times DESC";
            //"SELECT DISTINCT * FROM dbo.ScriptListTable";
            SqlCommand cmd = new SqlCommand(strQuery);
            DataTable dt = clsSqldata.GetData(cmd);

            gvMaster.Visible = true;
            gvMaster.DataSource = dt;
            gvMaster.DataBind();

        }
        catch (Exception a)
        {
            // lblError.Text = (a.Message.ToString());
        }
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("MySubList.aspx");
    }
    protected void ddlStrategyList_SelectedIndexChanged(object sender, EventArgs e)
    {
        //lblStrategyName.Text = ddlStrategyList.SelectedValue.ToString();
    }
    protected void btnSendOrder_Click(object sender, EventArgs e)
    {

    }
}