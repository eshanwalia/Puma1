﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.ServiceModel.Syndication;
using System.Text;
using System.Data.SqlClient;
using System.Data;

public partial class User_UserHome : System.Web.UI.Page
{
    StringBuilder table = new StringBuilder();

    protected void Page_Load(object sender, EventArgs e)
    {
        datbind();
        //PlaceHolder1.Controls.Add(new Literal { Text = f_NewFeed() });
        //phUserDetails.Controls.Add(new Literal { Text = "<strong>User Name: Rahul </br> Pancard: AAAAAAAAAA </br> Contact: 0000000000 </br></strong>" });
    }
    protected void lnkUnsubscribe_Click(object sender, EventArgs e)
    {

    }
    protected void gvMaster_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //e.CommandArgument.ToString();

        //string strQuery;
        //SqlCommand cmd;
        ////update
        //strQuery = "update tblSubcribLiveOrders set SubscribActive=@SubscribActive where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
        //cmd = new SqlCommand(strQuery);
        //cmd.Parameters.AddWithValue("@SubscribActive", 0);
        //cmd.Parameters.AddWithValue("@Clinetid", gvMaster.SelectedRow.Cells[0].Text);
        //cmd.Parameters.AddWithValue("@StrategyID", gvMaster.SelectedRow.Cells[0].Text);
        //cmd.Parameters.AddWithValue("@ScripCode", gvMaster.SelectedRow.Cells[0].Text);
        //bool res =clsSqldata.InsertUpdateData(cmd);
    }
    protected void gvMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        ////   TextBox1.Text = gvMaster.SelectedRow.Cells[0].Text;
        ////   int RowIndex = Convert.ToInt32(e.CommandArgument.ToString());
        //   string strQuery;
        //   SqlCommand cmd;
        //   //update
        //   strQuery = "update tblSubcribLiveOrders set SubscribActive=@SubscribActive where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
        //   cmd = new SqlCommand(strQuery);
        //   cmd.Parameters.AddWithValue("@SubscribActive", 0);
        //   cmd.Parameters.AddWithValue("@Clinetid", gvMaster.SelectedRow.Cells[0].Text);
        //   cmd.Parameters.AddWithValue("@StrategyID", gvMaster.SelectedRow.Cells[0].Text);
        //   cmd.Parameters.AddWithValue("@ScripCode", gvMaster.SelectedRow.Cells[0].Text);
        //   bool res = clsSqldata.InsertUpdateData(cmd);
    }
    void datbind()
    {
        try
        {
            string strQuery = "SELECT DISTINCT tblSubcribLiveOrders.ClientId, dbo.tblStrategies.StrategyName, dbo.tblStrategies.StrategyInfo, tblSubcribLiveOrders.scripcode, dbo.ScriptListTable.ScripName, " +
                         "dbo.ScriptListTable.FullScripName FROM  tblSubcribLiveOrders INNER JOIN dbo.tblStrategies ON tblSubcribLiveOrders.StrategyId = dbo.tblStrategies.custkey INNER JOIN "+
                         "dbo.ScriptListTable ON tblSubcribLiveOrders.scripcode = dbo.ScriptListTable.ScripName";
                //"SELECT DISTINCT  tblSubcribLiveOrders.ClientId, dbo.tblStrategies.StrategyName, tblSubcribLiveOrders.scripcode FROM tblSubcribLiveOrders INNER JOIN dbo.tblStrategies ON tblSubcribLiveOrders.StrategyId = dbo.tblStrategies.custkey";
            //"SELECT DISTINCT ClientId,StrategyId,ScripCode from tblSubcribLiveOrders";
            SqlCommand cmd = new SqlCommand(strQuery);
            DataTable dt = clsSqldata.GetData(cmd);

            gvMaster.Visible = true;
            gvMaster.DataSource = dt;
            gvMaster.DataBind();

        }
        catch (Exception a)
        {
            // lblError.Text = (a.Message.ToString());
        }
    }

    string f_NewFeed()
    {
        string url = "http://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms";
        XmlReader reader = XmlReader.Create(url);
        SyndicationFeed feed = SyndicationFeed.Load(reader);
        reader.Close();
        table.Append("<table>");
        int count = 0;
        foreach (SyndicationItem item in feed.Items)
        {
            if (count < 3)
            {
                String subject = item.Title.Text;

                String summary = item.Summary.Text;
                table.Append("<tr> <th style='padding-top: 10px;padding-bottom: 10px;padding-left: 10px;padding-right: 10px;'> " + summary + " </th></tr>");
                count++;
            }
            else
                break;
        }
        table.Append("</table>");

        return table.ToString();
    }
}