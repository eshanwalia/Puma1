﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class User_UserLogin : System.Web.UI.Page
{
    //clsEmployeeLogin_Logic LoginObj = new clsEmployeeLogin_Logic();
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["UserName"] = null;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        checkSqlInject objsqlInject = new checkSqlInject();
        if (!objsqlInject.checkForSQLInjection(txtLoginId.Text.Trim()) & !objsqlInject.checkForSQLInjection(txtPassword.Text.Trim()))
        {
            try
            {
                string strQuery = "select username from tbl_login where username=@UserName and password=@Password and active = 1 and isDeleted = 0";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.AddWithValue("@UserName", txtLoginId.Text.Trim());
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
                DataTable dt = clsSqldata.GetLogin(cmd);

                if (dt.Rows.Count > 0)
                {
                    lblError.Visible = false;
                    Session["UserName"] = dt.Rows[0][0].ToString();
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Invalid Login ID/Password";
                }
            }
            catch (Exception ex)
            {
                lblError.Visible = true;
                lblError.Text = ex.Message.ToString();
            }
            Response.Redirect("UserHome.aspx");
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You have been attacked by SQL Injection')", true);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("../index.aspx");
    }
}