﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_UserDailyReports : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //   phScriptList.Controls.Add(new Literal { Text = "<strong>User Name: Rahul </br> Pancard: AAAAAAAAAA </br> Contact: 0000000000 </br></strong>" });
        DataTable dt = new DataTable();
        dt.Columns.Add("Exchange");
        dt.Columns.Add("StockName");
        dt.Columns.Add("Quantity");
        dt.Columns.Add("OrderPrice");
        dt.Columns.Add("MarketPrice");

        var dr = dt.NewRow();
        dr["Exchange"] = "NSE";
        dr["StockName"] = "Reliance";
        dr["Quantity"] = "1";
        dr["OrderPrice"] = "1000";
        dr["MarketPrice"] = "1030";

        dt.Rows.Add(dr);
        gvNetPosition.DataSource = dt;
        gvNetPosition.DataBind();
        gvOrderHist.DataSource = dt;
        gvOrderHist.DataBind();
    }

    void datbind()
    {
        try
        {
            string strQuery = "SELECT DISTINCT * FROM dbo.ScriptListTable";
            SqlCommand cmd = new SqlCommand(strQuery);
            DataTable dt = clsSqldata.GetData(cmd);
            foreach (DataRow dr in dt.Rows)
            {
                dr[0].ToString();
            }



        }
        catch (Exception a)
        {
            // lblError.Text = (a.Message.ToString());
        }
    }
}