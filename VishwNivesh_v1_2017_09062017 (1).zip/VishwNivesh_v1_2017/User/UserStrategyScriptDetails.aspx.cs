﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class User_UserStrategyScriptDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Session["UserName"] == null) || (Session["UserName"].ToString() == ""))
        {
            Response.Redirect("Userlogin.aspx");
        }
        try
        {
            SqlCommand cmd1 = new SqlCommand("select clientid from tblRegClientSharekhan where userid=@userid");
            cmd1.Parameters.AddWithValue("@userid", Session["UserName"].ToString());
            DataTable dt1 = GetData(cmd1);
            lblClientID.Text = dt1.Rows[0][0].ToString();
            lblUserID.Text = Session["UserName"].ToString().ToUpper();
            //StrategyName
            SqlCommand cmdstname = new SqlCommand("SELECT StrategyInfo FROM dbo.tblStrategies where custkey=@StrategyId");
            cmdstname.Parameters.AddWithValue("@StrategyId", Request.QueryString["StrategyID"]);
            DataTable dtcmdstname = GetData(cmdstname);
            lblStrategyName.Text = dtcmdstname.Rows[0][0].ToString();


            lblStrategyId.Text = Request.QueryString["StrategyID"];
            lblScriptName.Text = Request.QueryString["ScripCode"];
            //In below query have to update if we are spliting order send and send email subscription
            string strQuery = "select 1 from tblSubcribLiveOrders where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
            SqlCommand cmd = new SqlCommand(strQuery);
            cmd.Parameters.AddWithValue("@Clinetid", lblClientID.Text.Trim());
            cmd.Parameters.AddWithValue("@StrategyID", lblStrategyId.Text.Trim());
            cmd.Parameters.AddWithValue("@ScripCode", lblScriptName.Text.Trim());
            DataTable dt = GetData(cmd);
            if (int.Parse(dt.Rows[0][0].ToString()) == 1)
            {
                btnSubcribe.Text = "Unsubscribe";
                btnSubcribe.BackColor = System.Drawing.Color.Red;
            }
            else
            {
                btnSubcribe.Text = "Subscribe";
                btnSubcribe.BackColor = System.Drawing.Color.Green;
            }

            FillTrainingsDetails();
        }
        catch
        {

        }

        if (!Page.IsPostBack)
        {
            //FillTrainingsDetails();
        }
        //System.Text.StringBuilder sb = new System.Text.StringBuilder();
        //sb.Append("<script type = 'text/javascript'>");
        //sb.Append("window.onload=function(){");
        //sb.Append("alert('");
        //sb.Append("Please Enter Strategy Id and Script Name first");
        //sb.Append("')};");
        //sb.Append("</script>");
        //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());

        //if (this.Page.PreviousPage != null)
        //{
        //    int rowIndex = int.Parse(Request.QueryString["RowIndex"]);
        //    GridView GridView1 = (GridView)this.Page.PreviousPage.FindControl("gvMaster");
        //    GridViewRow row = GridView1.Rows[rowIndex];
        //    lblClientID.Text = row.Cells[0].Text;
        //    lblStrategyId.Text = row.Cells[1].Text;
        //    lblStrategyName.Text = row.Cells[2].Text;
        //}
    }
    public string getHike(decimal dhike)
    {
        return Math.Round(dhike / 100).ToString();
    }
    protected void FillTrainingsDetails()
    {
        string strQuery = "SELECT Scripcode, Price, BuySell,Time FROM tblStNetPosition_Website WHERE (Scripcode = @ScripCode) order by time desc";
        SqlCommand cmd = new SqlCommand(strQuery);
        cmd.Parameters.AddWithValue("@ScripCode", lblScriptName.Text.Trim());
        DataTable dt = GetData(cmd);
        //gvOnJob.DataSource = dt;
        //gvOnJob.DataBind();
        GridView1.DataSource = dt;
        GridView1.DataBind();


        //objEmployee.EmployeeId = Convert.ToInt32(Request["EmpId"].ToString());

        //objEmployee.DepartmentId = Convert.ToInt32(Request["Department"].ToString());

        //objEmployee.SelectById();
        //lblEmployeeName.Text = objEmployee.Name.ToString();
        //lblDesignation.Text = objEmployee.Designation.ToString();
        //lblDegree.Text = objEmployee.Degree.ToString();
        //if (objEmployee.DOJ.CompareTo(Convert.ToDateTime("01/01/1900")) > 0)
        //{
        //    lblDOJ.Text = objEmployee.DOJ.ToString("dd/MM/yyyy");
        //}
        //else
        //{
        //    lblDOJ.Text = "";
        //}
        //lblEmpId.Text = "EMP" + objEmployee.EmployeeId.ToString();
        //objDeparment.DepartmentId = objEmployee.DepartmentId;
        //objDeparment.SelectById();
        //lblDepartment.Text = objDeparment.DepartmentName.ToString();
        //objTrainings.EmployeeId = Convert.ToInt32(Request["EmpId"].ToString());
        //objTrainings.JobType = 1;
        //BindGrid(objEmployee.EmployeeId, objEmployee.DepartmentId);
        ////gvOnJob.DataSource = objTrainings.SelectByEmployee_Eval();
        ////gvOnJob.DataBind();
        //objTrainings.EmployeeId = Convert.ToInt32(Request["EmpId"].ToString());
        //objTrainings.JobType = 2;
        //gvOffJob.DataSource = objTrainings.SelectByEmployee();
        //gvOffJob.DataBind();
    }
    private void BindGrid(int EmpId, int DepId)
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT EmployeeId, totalLeave,  HRRate, AdminRate, (totalLeave / 2) * (CTC / 365) * (SELECT RateValue FROM tblRating WHERE        (Department = (SELECT        DepartmentName FROM            tblDepartment WHERE        (DepartmentId = " + DepId + "))) AND (Rating = (SELECT        SUM(Rates) / 2 AS Expr1 FROM            tblEmpRate WHERE        (Empid = " + EmpId + ")))) AS ExpHike, totalLeave / 2 + 26 AS ExpLeaves FROM            tblEmployee WHERE        (EmployeeId = " + EmpId + ")"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            gvOnJob.DataSource = dt;
                            gvOnJob.DataBind();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append("Please Enter Strategy Id and Script Name first");
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }
    }
    protected void btnSubcribe_Click(object sender, EventArgs e)
    {
        if (lblClientID.Text != "" && lblStrategyId.Text != "" && lblScriptName.Text != "")
            if (btnSubcribe.Text == "Subscribe")
            {
                string strQuery;
                SqlCommand cmd;

                //insert
                strQuery = "insert into tblSubcribLiveOrders (ClientId,userId,StrategyID,scripcode,SubscribDate, SubscribActive) values(@Clinetid," +
                    "@UserID,@StrategyID,@ScripCode,@SubscribDate,@SubscribActive)";
                cmd = new SqlCommand(strQuery);
                cmd.Parameters.AddWithValue("@Clinetid", lblClientID.Text);
                cmd.Parameters.AddWithValue("@UserID", lblUserID.Text);
                cmd.Parameters.AddWithValue("@StrategyID", lblStrategyId.Text);
                cmd.Parameters.AddWithValue("@ScripCode", lblScriptName.Text);
                cmd.Parameters.AddWithValue("@SubscribDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@SubscribActive", 1);
                cmd.Parameters.AddWithValue("@ManualOrder", 1);
                bool res = InsertUpdateData(cmd);
                if (res)
                {
                    btnSubcribe.Text = "Unsubscribe";
                    btnSubcribe.BackColor = System.Drawing.Color.Red;
                }
            }
            else if (btnSubcribe.Text == "Unsubscribe")
            {
                string strQuery;
                SqlCommand cmd;
                //update
                strQuery = "update tblSubcribLiveOrders set SubscribActive=@SubscribActive where Clientid=@Clinetid and StrategyID=@StrategyID and ScripCode=@ScripCode";
                cmd = new SqlCommand(strQuery);
                cmd.Parameters.AddWithValue("@SubscribActive", 0);
                cmd.Parameters.AddWithValue("@ManualOrder", 0);
                cmd.Parameters.AddWithValue("@Clinetid", lblClientID.Text);
                cmd.Parameters.AddWithValue("@StrategyID", lblStrategyId.Text);
                cmd.Parameters.AddWithValue("@ScripCode", lblScriptName.Text);
                bool res = InsertUpdateData(cmd);
                if (res)
                {
                    btnSubcribe.Text = "Subscribe";
                    btnSubcribe.BackColor = System.Drawing.Color.Green;
                }
            }
            else
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script type = 'text/javascript'>");
                sb.Append("window.onload=function(){");
                sb.Append("alert('");
                sb.Append("Kindly Register first with Sharekhan Account Details.");
                sb.Append("')};");
                sb.Append("</script>");
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                // Response.Redirect("SharekhanAccReg.aspx");
            }
        else
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append("No Data.");
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }

    }

    private Boolean InsertUpdateData(SqlCommand cmd)
    {
        String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
        SqlConnection con = new SqlConnection(strConnString);
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            return true;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            return false;
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
        SqlConnection con = new SqlConnection(strConnString);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            return dt;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            return null;
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }
    }
}