﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for clsGetWebReqResp
/// </summary>
public class clsGetWebReqResp
{
    public clsGetWebReqResp()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public  StringBuilder f_GetplacholderStrategy()
    {
        StringBuilder table = new StringBuilder();
        try
        {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["VishwNivesh_DB2"].ConnectionString;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "SELECT StrategyName, AVG(BOOKEDPL) AS Expr1 FROM tblNetPositionWeb WHERE (ScriptCode = '22') GROUP BY StrategyName";
                cmd.Connection = con;
                SqlDataReader rd = cmd.ExecuteReader();
                int i = 1;
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        table.Append("<tr href='/en/history/deposits/BTC'><td width='40%'>"+rd[0].ToString()+"</td><td width='60%' id='balance_"+i+"'>"+
                            rd[1].ToString()+"</td> </tr>") ;
                           
                    }
                }
                rd.Close();
                con.Close();
        }
        catch
        {
        }
        return table;
    }
}